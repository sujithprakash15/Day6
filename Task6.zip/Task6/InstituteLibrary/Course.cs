﻿namespace InstituteLibrary;

public class Course
{
    public int CourseCode { get; set; }
    public string? CourseTitle { get; set; }
    public int CourseDuration { get; set; }
    public int CourseFee { get; set; }

}
