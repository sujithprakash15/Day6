﻿namespace InstituteLibrary;

public class Student
{
    public int RollNo { get; set; }
    public int BatchCode { get; set; }
    public string? StudentName { get; set; }
    public string? StudentAddress { get; set; }

}
