﻿namespace InstituteLibrary;

public class InstituteException : Exception
{
   public InstituteException(string msg) : base(msg)
    {
        
    }
}
